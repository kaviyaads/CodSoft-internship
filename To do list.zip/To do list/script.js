document.addEventListener('DOMContentLoaded', loadTasks);

document.getElementById('task-form').addEventListener('submit', addTask);
document.getElementById('task-list').addEventListener('click', manageTask);

function loadTasks() {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.forEach(task => addTaskToDOM(task));
}

function addTask(e) {
    e.preventDefault();
    let taskInput = document.getElementById('new-task');
    let taskText = taskInput.value;
    let task = { text: taskText, id: Date.now().toString() };

    addTaskToDOM(task);
    saveTask(task);
    taskInput.value = '';
}

function addTaskToDOM(task) {
    let li = document.createElement('li');
    li.setAttribute('data-id', task.id);
    li.innerHTML = `
        <span>${task.text}</span>
        <div>
            <button class="edit">Edit</button>
            <button class="delete">Delete</button>
        </div>
    `;
    document.getElementById('task-list').appendChild(li);
}

function saveTask(task) {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.push(task);
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function manageTask(e) {
    if (e.target.classList.contains('delete')) {
        deleteTask(e.target.parentElement.parentElement);
    } else if (e.target.classList.contains('edit')) {
        editTask(e.target.parentElement.parentElement);
    }
}

function deleteTask(taskElement) {
    let taskId = taskElement.getAttribute('data-id');
    taskElement.remove();
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks = tasks.filter(task => task.id !== taskId);
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function editTask(taskElement) {
    let taskId = taskElement.getAttribute('data-id');
    let newTaskText = prompt('Edit your task:', taskElement.firstElementChild.textContent);
    if (newTaskText) {
        taskElement.firstElementChild.textContent = newTaskText;
        let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        tasks = tasks.map(task => {
            if (task.id === taskId) {
                task.text = newTaskText;
            }
            return task;
        });
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }
}
